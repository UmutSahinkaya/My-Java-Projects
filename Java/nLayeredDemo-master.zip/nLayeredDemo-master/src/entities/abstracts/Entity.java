package entities.abstracts;

public interface Entity {
}
