package jLogger;

import java.awt.*;

public class jLoggerManager {
    public void log(String message){
        System.out.println("J Logger ile loglandı.  "+message);
    }
}
