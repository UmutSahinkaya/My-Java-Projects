package core;

public interface LoggerService {
    void logToSystem(String message);
}
