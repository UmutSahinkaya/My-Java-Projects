package com.example.hrms.business.checkHelper.concretes;

import com.example.hrms.entities.concretes.Employer;

public class EmployeeCheckHelper {
    public static boolean isConfirmed(Employer employer){
        return true;
    }
}
