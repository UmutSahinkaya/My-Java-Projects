package inheritance;

public class Customer {
	private int id;
	String customerNumber;
}
