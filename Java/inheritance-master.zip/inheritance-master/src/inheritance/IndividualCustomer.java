package inheritance;

public class IndividualCustomer extends Customer {
	private String firstName;
	private String secondName;
	private String identity;
}
