package Inheritance2;

public class Logger {
	public void log(){
	System.out.println("Ortak Konfig�rasyon");
    }
}
