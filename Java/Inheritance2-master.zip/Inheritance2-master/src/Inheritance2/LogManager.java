package Inheritance2;

public class LogManager {
    public void log() 
	{
	
	}
}
