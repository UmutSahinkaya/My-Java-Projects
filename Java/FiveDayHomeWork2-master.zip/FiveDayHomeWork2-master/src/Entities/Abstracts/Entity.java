package Entities.Abstracts;

public interface Entity {
}
