public interface ICustomerDal {
    void add();
}
